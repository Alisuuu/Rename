import os
import zipfile
import tempfile
import shutil
import time # Adicionado para timestamp

# --- Configurações ---
# Nomes das pastas relativos ao diretório do script
NOME_PASTA_FONTE_MTZ = "mtz1"
NOME_PASTA_DESTINO_MTZ = "mtz2"

# Obtém o diretório onde o script atual está localizado
script_dir = os.path.dirname(os.path.abspath(__file__))

# Constrói os caminhos completos para as pastas fonte e destino
PASTA_FONTE_MTZ = os.path.join(script_dir, NOME_PASTA_FONTE_MTZ)
PASTA_DESTINO_MTZ = os.path.join(script_dir, NOME_PASTA_DESTINO_MTZ)

# Nomes das subpastas dentro da pasta temporária para as extrações
FONTE_EXTRACT_SUBDIR = "fonte_extraido"
DESTINO_EXTRACT_SUBDIR = "destino_extraido"

# --- Funções Auxiliares ---

def garantir_pastas():
    """Cria as pastas de fonte e destino se não existirem."""
    os.makedirs(PASTA_FONTE_MTZ, exist_ok=True)
    os.makedirs(PASTA_DESTINO_MTZ, exist_ok=True)
    print(f"Pasta fonte '{PASTA_FONTE_MTZ}' garantida em: {PASTA_FONTE_MTZ}")
    print(f"Pasta destino '{PASTA_DESTINO_MTZ}' garantida em: {PASTA_DESTINO_MTZ}")

def encontrar_arquivos_mtz(diretorio):
    """Encontra todos os arquivos .mtz em um diretório."""
    if not os.path.exists(diretorio):
        return [] # Retorna lista vazia se o diretório não existe

    arquivos_mtz = [f for f in os.listdir(diretorio) if f.endswith(".mtz")]
    return arquivos_mtz

def listar_e_selecionar(lista_itens, prompt):
    """Lista itens numerados e permite ao usuário selecionar um."""
    if not lista_itens:
        print("Nenhum item para selecionar.")
        return None

    print(prompt)
    for i, item in enumerate(lista_itens):
        print(f"{i + 1}: {item}")

    while True:
        try:
            escolha = input(f"Digite o número do item desejado (1-{len(lista_itens)}): ")
            indice_escolhido = int(escolha) - 1
            if 0 <= indice_escolhido < len(lista_itens):
                return lista_itens[indice_escolhido]
            else:
                print("Número inválido. Tente novamente.")
        except ValueError:
            print("Entrada inválida. Digite um número.")

def listar_e_selecionar_componentes(pasta_extraida_raiz, prompt):
    """Lista itens numerados de uma pasta extraída e permite ao usuário selecionar múltiplos."""
    caminhos_relativos = []
    # Percorre a pasta extraída para listar todos os arquivos e diretórios
    if os.path.exists(pasta_extraida_raiz):
        for root, dirs, files in os.walk(pasta_extraida_raiz):
            # Garante que o caminho seja relativo à pasta raiz da extração
            rel_root = os.path.relpath(root, pasta_extraida_raiz)

            # Adiciona diretórios (com barra final para clareza)
            # Adiciona apenas se não for o diretório raiz da extração '.'
            for d in dirs:
                 caminho_completo_dir = os.path.join(rel_root, d)
                 if caminho_completo_dir != '.': # Evita adicionar '.'
                    caminhos_relativos.append(caminho_completo_dir + os.sep)

            # Adiciona arquivos
            for f in files:
                if rel_root == '.': # Arquivos na raiz da extração
                    caminhos_relativos.append(f)
                else: # Arquivos em subpastas
                    caminhos_relativos.append(os.path.join(rel_root, f))

    caminhos_relativos.sort() # Opcional: ordena para facilitar a visualização

    if not caminhos_relativos:
         print("Nenhum componente encontrado na pasta extraída.")
         return []

    print("\nComponentes disponíveis para seleção:")
    for i, item in enumerate(caminhos_relativos):
        print(f"{i + 1}: {item}")

    while True:
        escolhas_str = input(f"Digite os números dos componentes desejados separados por vírgula (ex: 1,3,5) ou 'todos' para selecionar tudo: ")
        if escolhas_str.lower() == 'todos':
            return caminhos_relativos # Retorna todos os caminhos relativos

        try:
            indices_escolhidos = [int(num.strip()) - 1 for num in escolhas_str.split(',') if num.strip()]
            componentes_selecionados = []
            todos_validos = True
            if not indices_escolhidos: # Verifica se a lista de índices não está vazia após split
                 print("Nenhum número digitado.")
                 todos_validos = False

            if todos_validos:
                for indice in indices_escolhidos:
                    if 0 <= indice < len(caminhos_relativos):
                        # O caminho selecionado é o caminho relativo dentro do MTZ original
                        componentes_selecionados.append(caminhos_relativos[indice])
                    else:
                        print(f"Número {indice + 1} inválido.")
                        todos_validos = False
                        break

            if todos_validos and componentes_selecionados:
                 return componentes_selecionados # Retorna a lista de caminhos relativos selecionados
            else:
                 print("Seleção inválida. Tente novamente.")

        except ValueError:
            print("Entrada inválida. Use números separados por vírgula ou digite 'todos'.")

def copiar_componentes(fonte_raiz, destino_raiz, componentes_rel_paths):
    """Copia componentes de uma pasta para outra, substituindo no destino."""
    print("\nCopiando componentes selecionados para a extração de destino...")
    for rel_path in componentes_rel_paths:
        src_path = os.path.join(fonte_raiz, rel_path)
        dest_path = os.path.join(destino_raiz, rel_path)

        if not os.path.exists(src_path):
            print(f"Aviso: Fonte '{rel_path}' não encontrada em '{fonte_raiz}'. Pulando.")
            continue

        try:
            if os.path.isdir(src_path):
                # Se o destino já existe e é um diretório, removemos antes de copiar
                if os.path.exists(dest_path):
                    print(f"Substituindo diretório existente: {rel_path}")
                    shutil.rmtree(dest_path)
                else:
                    print(f"Adicionando novo diretório: {rel_path}")

                # Copia a árvore de diretórios completa
                shutil.copytree(src_path, dest_path) # dirs_exist_ok não é usado aqui pois removemos antes
                print(f"Diretório copiado: {rel_path}")

            elif os.path.isfile(src_path):
                # Cria o diretório pai no destino se não existir
                os.makedirs(os.path.dirname(dest_path), exist_ok=True)
                # Copia o arquivo (substitui se existir)
                shutil.copy2(src_path, dest_path) # copy2 tenta preservar metadados
                print(f"Arquivo copiado: {rel_path}")

        except Exception as e:
            print(f"Erro ao copiar '{rel_path}': {e}")


    print("Cópia de componentes concluída.")


def compactar_diretorio_para_mtz(diretorio_origem, caminho_mtz_destino):
    """Compacta todo o conteúdo de um diretório em um arquivo MTZ."""
    print(f"\nCompactando conteúdo modificado em '{diretorio_origem}' para '{caminho_mtz_destino}' (substituindo o arquivo original)...")
    try:
        # O modo 'w' irá criar o arquivo se ele não existir ou SOBRESCREVÊ-LO se existir
        # Isso atende ao requisito de substituir o arquivo original na pasta mtz2
        with zipfile.ZipFile(caminho_mtz_destino, 'w', zipfile.ZIP_DEFLATED) as mtz_zip:
            for root, dirs, files in os.walk(diretorio_origem):
                # Calcula o caminho relativo do diretório atual em relação à raiz da compactação
                # Se root for igual a diretorio_origem, rel_root será '.'
                rel_root = os.path.relpath(root, diretorio_origem)

                # Adiciona diretórios (garante que diretórios vazios sejam adicionados)
                # Exceto o diretório raiz '.' ao adicionar DIRETÓRIOS explicitamente.
                # zipfile.write(caminho_pasta, arcname=caminho_pasta_no_zip) adiciona a pasta
                # e seu conteúdo, se houver. Se for só a pasta, adiciona só ela.
                # Precisamos garantir que mesmo pastas vazias sejam adicionadas.
                if rel_root != '.':
                    mtz_zip.write(root, arcname=rel_root + '/')

                # Adiciona arquivos
                for file in files:
                    full_file_path = os.path.join(root, file)
                    # Calcula o caminho relativo do arquivo em relação à raiz da compactação
                    if rel_root == '.': # Arquivos na raiz da extração
                         file_arcname = file
                    else: # Arquivos em subpastas
                         file_arcname = os.path.join(rel_root, file)
                    mtz_zip.write(full_file_path, arcname=file_arcname)


        print("Compactação para MTZ concluída com sucesso!")
        return True

    except Exception as e:
        print(f"Erro ao compactar o diretório: {e}")
        import traceback
        traceback.print_exc()
        return False

# --- Fluxo Principal ---
if __name__ == "__main__":
    print("--- Ferramenta de Combinação e Modificação de Temas MTZ para HyperOS ---")

    garantir_pastas()

    # 1. Encontrar e selecionar tema FONTE (de onde pegar componentes)
    arquivos_fonte_mtz = encontrar_arquivos_mtz(PASTA_FONTE_MTZ)
    if not arquivos_fonte_mtz:
        print(f"\nNenhum arquivo .mtz encontrado na pasta fonte '{PASTA_FONTE_MTZ}'.")
        print("Por favor, coloque o tema de onde deseja copiar componentes lá.")
        input("\nPressione Enter para sair.")
        exit()

    nome_arquivo_fonte = listar_e_selecionar(arquivos_fonte_mtz, "\nSelecione o arquivo MTZ FONTE (de onde copiar componentes):")
    if not nome_arquivo_fonte:
         input("\nNenhuma seleção feita. Pressione Enter para sair.")
         exit()
    caminho_completo_fonte = os.path.join(PASTA_FONTE_MTZ, nome_arquivo_fonte)

    # 2. Encontrar e selecionar tema DESTINO (o tema que será modificado)
    arquivos_destino_mtz = encontrar_arquivos_mtz(PASTA_DESTINO_MTZ)
    if not arquivos_destino_mtz:
        print(f"\nNenhum arquivo .mtz encontrado na pasta destino '{PASTA_DESTINO_MTZ}'.")
        print("Por favor, coloque o tema que deseja modificar lá.")
        input("\nPressione Enter para sair.")
        exit()

    nome_arquivo_destino = listar_e_selecionar(arquivos_destino_mtz, "\nSelecione o arquivo MTZ DESTINO (o tema que será modificado):")
    if not nome_arquivo_destino:
         input("\nNenhuma seleção feita. Pressione Enter para sair.")
         exit()
    caminho_completo_destino = os.path.join(PASTA_DESTINO_MTZ, nome_arquivo_destino)

    # 3. Criar pasta temporária e extrair AMBOS os MTZs
    with tempfile.TemporaryDirectory() as pasta_temp:
        caminho_extraido_fonte = os.path.join(pasta_temp, FONTE_EXTRACT_SUBDIR)
        caminho_extraido_destino = os.path.join(pasta_temp, DESTINO_EXTRACT_SUBDIR)

        print(f"\nCriando pasta temporária: {pasta_temp}")
        print(f"Diretório de extração da fonte: {caminho_extraido_fonte}")
        print(f"Diretório de extração do destino: {caminho_extraido_destino}")

        try:
            # Extrair Fonte
            print(f"\nExtraindo tema FONTE '{nome_arquivo_fonte}'...")
            os.makedirs(caminho_extraido_fonte, exist_ok=True)
            with zipfile.ZipFile(caminho_completo_fonte, 'r') as zip_ref:
                zip_ref.extractall(caminho_extraido_fonte)
            print("Extração da FONTE concluída.")

            # Extrair Destino
            print(f"\nExtraindo tema DESTINO '{nome_arquivo_destino}'...")
            os.makedirs(caminho_extraido_destino, exist_ok=True)
            with zipfile.ZipFile(caminho_completo_destino, 'r') as zip_ref:
                zip_ref.extractall(caminho_extraido_destino)
            print("Extração do DESTINO concluída.")

            # 4. Listar componentes da FONTE para seleção
            componentes_selecionados_rel_paths = listar_e_selecionar_componentes(
                caminho_extraido_fonte,
                "\nComponentes do tema FONTE. Selecione quais deseja COPIAR para o tema DESTINO:"
                )

            if componentes_selecionados_rel_paths:
                # 5. Copiar componentes selecionados da FONTE para o DESTINO extraído
                copiar_componentes(
                    caminho_extraido_fonte,
                    caminho_extraido_destino,
                    componentes_selecionados_rel_paths
                )

                # 6. Compactar o conteúdo MODIFICADO da extração do DESTINO e SUBSTITUIR o arquivo original
                # O caminho de saída é o mesmo caminho do arquivo de destino original
                caminho_mtz_final = caminho_completo_destino

                # Opcional: Criar um backup do arquivo de destino original antes de sobrescrever
                backup_path = f"{caminho_completo_destino}.bak_{int(time.time())}"
                try:
                     shutil.copy2(caminho_completo_destino, backup_path)
                     print(f"\nBackup do tema destino original criado em: {backup_path}")
                except FileNotFoundError:
                     print("\nNão foi possível criar backup (arquivo original não encontrado, o que não deveria acontecer).")
                except Exception as e:
                     print(f"\nAviso: Não foi possível criar o backup do tema destino original: {e}")


                sucesso = compactar_diretorio_para_mtz(
                    caminho_extraido_destino,
                    caminho_mtz_final # Usa o caminho do arquivo original para sobrescrever
                )

                if sucesso:
                     print(f"\nProcesso finalizado. O tema DESTINO original foi MODIFICADO e salvo em '{caminho_mtz_final}'")
                     print("Um backup do tema original foi criado (se a criação do backup foi bem sucedida).")
                else:
                     print("\nProcesso falhou durante a criação do novo MTZ modificado.")

            else:
                print("\nNenhum componente selecionado da FONTE. O tema DESTINO não será modificado.")

        except FileNotFoundError as e:
            print(f"\nErro: Arquivo não encontrado durante a extração ou cópia. Verifique se os arquivos MTZ selecionados existem e não estão corrompidos: {e}")
        except zipfile.BadZipFile as e:
            print(f"\nErro: Um dos arquivos MTZ não é válido ou está corrompido: {e}")
        except Exception as e:
            print(f"\nOcorreu um erro inesperado durante o processo: {e}")
            import traceback
            traceback.print_exc() # Imprime o rastreamento completo do erro para depuração

        # A pasta temporária é removida automaticamente ao sair do bloco 'with'

    print("\nPressione Enter para sair.")
    input() # Aguarda a tecla Enter para fechar a janela do console (se estiver executando em uma)