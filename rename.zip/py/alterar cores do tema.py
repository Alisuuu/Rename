import os
import re
import zipfile
import shutil
from collections import Counter

def eh_zip(caminho):
    try:
        with open(caminho, 'rb') as f:
            assinatura = f.read(4)
        return assinatura == b'PK\x03\x04'
    except:
        return False

def coletar_cores_em_conteudo(conteudo):
    padroes_cores = [
        r'#([0-9a-fA-F]{3,8})\b',
        r'rgb\(\s*\d{1,3}%?\s*,\s*\d{1,3}%?\s*,\s*\d{1,3}%?\s*\)',
        r'rgba\(\s*\d{1,3}%?\s*,\s*\d{1,3}%?\s*,\s*\d{1,3}%?\s*,\s*[\d.]+\s*\)',
        r'\b(red|green|blue|yellow|purple|orange|gray|black|white|cyan|magenta|pink|brown)\b'
    ]
    padrao_cor = re.compile('|'.join(padroes_cores), re.IGNORECASE)
    return [m.group(0).lower() for m in padrao_cor.finditer(conteudo)]

def coletar_cores_em_xmls(diretorio):
    cores = []
    for root, dirs, files in os.walk(diretorio):
        for nome in files:
            if nome.lower().endswith('.xml'):
                caminho = os.path.join(root, nome)
                try:
                    with open(caminho, 'r', encoding='utf-8') as f:
                        conteudo = f.read()
                    cores.extend(coletar_cores_em_conteudo(conteudo))
                except:
                    pass
    return cores

def extrair_zip_sem_ext(caminho_zip_sem_ext, pasta_destino):
    try:
        with zipfile.ZipFile(caminho_zip_sem_ext, 'r') as zipf:
            zipf.extractall(pasta_destino)
        return True
    except Exception as e:
        print(f"❌ Erro ao extrair {caminho_zip_sem_ext}: {e}")
        return False

def processar_arquivos_para_coleta(diretorio, cores):
    for root, dirs, files in os.walk(diretorio):
        for nome in files:
            caminho = os.path.join(root, nome)
            if nome.lower().endswith('.xml'):
                try:
                    with open(caminho, 'r', encoding='utf-8') as f:
                        conteudo = f.read()
                    cores.extend(coletar_cores_em_conteudo(conteudo))
                except:
                    pass
            else:
                if eh_zip(caminho):
                    pasta_temp_zip = caminho + '_temp'
                    if os.path.exists(pasta_temp_zip):
                        shutil.rmtree(pasta_temp_zip)
                    os.makedirs(pasta_temp_zip)
                    if extrair_zip_sem_ext(caminho, pasta_temp_zip):
                        processar_arquivos_para_coleta(pasta_temp_zip, cores)
                    shutil.rmtree(pasta_temp_zip)

def mostrar_cores_mais_frequentes(cores, limite=20):
    contagem = Counter(cores)
    mais_comuns = contagem.most_common(limite)
    print("\n🎨 Cores mais frequentes encontradas:")
    for i, (cor, qtd) in enumerate(mais_comuns, 1):
        print(f"{i}. {cor} ({qtd} vezes)")
    return [cor for cor, _ in mais_comuns]

def alterar_cores_em_xmls(diretorio, cor_antiga, cor_nova):
    cor_antiga_normalizada = cor_antiga.strip().lower()
    
    padroes_cores = [
        r'#([0-9a-fA-F]{3,8})\b',
        r'rgb\(\s*\d{1,3}%?\s*,\s*\d{1,3}%?\s*,\s*\d{1,3}%?\s*\)',
        r'rgba\(\s*\d{1,3}%?\s*,\s*\d{1,3}%?\s*,\s*\d{1,3}%?\s*,\s*[\d.]+\s*\)',
        r'\b(red|green|blue|yellow|purple|orange|gray|black|white|cyan|magenta|pink|brown)\b'
    ]
    padrao_cor = re.compile('|'.join(padroes_cores), re.IGNORECASE)
    
    for root, dirs, files in os.walk(diretorio):
        for nome in files:
            if nome.lower().endswith('.xml'):
                caminho = os.path.join(root, nome)
                alteracoes = 0
                try:
                    with open(caminho, 'r', encoding='utf-8') as f:
                        conteudo = f.read()
                    def substituir_cor(match):
                        nonlocal alteracoes
                        cor_encontrada = match.group(0)
                        if cor_encontrada.lower() == cor_antiga_normalizada:
                            alteracoes += 1
                            return cor_nova
                        return cor_encontrada
                    novo_conteudo = padrao_cor.sub(substituir_cor, conteudo)
                    if alteracoes > 0:
                        with open(caminho, 'w', encoding='utf-8') as f:
                            f.write(novo_conteudo)
                        print(f"✅ {os.path.relpath(caminho, diretorio)}: {alteracoes} alteração(ões)")
                except Exception as e:
                    print(f"❌ Erro ao processar {caminho}: {e}")

def extrair_modificar_recompactar_zip_sem_ext(caminho_zip_sem_ext, cor_antiga, cor_nova):
    pasta_temp = caminho_zip_sem_ext + '_temp'
    if os.path.exists(pasta_temp):
        shutil.rmtree(pasta_temp)
    os.makedirs(pasta_temp)

    try:
        with zipfile.ZipFile(caminho_zip_sem_ext, 'r') as zipf:
            zipf.extractall(pasta_temp)
    except Exception as e:
        print(f"❌ Erro ao extrair arquivo zip interno {caminho_zip_sem_ext}: {e}")
        return

    alterar_cores_em_xmls(pasta_temp, cor_antiga, cor_nova)

    try:
        with zipfile.ZipFile(caminho_zip_sem_ext, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(pasta_temp):
                for file in files:
                    caminho_completo = os.path.join(root, file)
                    relpath = os.path.relpath(caminho_completo, pasta_temp)
                    zipf.write(caminho_completo, arcname=relpath)
    except Exception as e:
        print(f"❌ Erro ao recompactar arquivo zip interno {caminho_zip_sem_ext}: {e}")

    shutil.rmtree(pasta_temp)

def processar_arquivos_recursivamente(diretorio, cor_antiga, cor_nova):
    for root, dirs, files in os.walk(diretorio):
        for nome in files:
            caminho = os.path.join(root, nome)
            if nome.lower().endswith('.xml'):
                alterar_cores_em_xmls(root, cor_antiga, cor_nova)
            else:
                if eh_zip(caminho):
                    print(f"🔄 Processando zip interno sem extensão: {os.path.relpath(caminho, diretorio)}")
                    extrair_modificar_recompactar_zip_sem_ext(caminho, cor_antiga, cor_nova)

def zipar_diretorio(pasta_origem, caminho_zip):
    with zipfile.ZipFile(caminho_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(pasta_origem):
            for file in files:
                caminho_completo = os.path.join(root, file)
                relpath = os.path.relpath(caminho_completo, pasta_origem)
                zipf.write(caminho_completo, arcname=relpath)

def main_loop():
    print("\n🎨 SUBSTITUIDOR DE CORES EM XML DENTRO DE .MTZ")
    print("----------------------------------------------")

    while True:
        # Primeiro precisa extrair o .mtz para coletar as cores
        mtz_arquivos = [f for f in os.listdir('.') if f.lower().endswith('.mtz')]
        if not mtz_arquivos:
            print("❌ Nenhum arquivo .mtz encontrado no diretório atual.")
            input("Pressione ENTER para tentar novamente ou Ctrl+C para sair...")
            continue

        nome_mtz = mtz_arquivos[0]
        pasta_temp = './temp_root'
        if os.path.exists(pasta_temp):
            shutil.rmtree(pasta_temp)
        os.makedirs(pasta_temp)

        print(f"📦 Extraindo arquivo .mtz: {nome_mtz} ...")
        try:
            with zipfile.ZipFile(nome_mtz, 'r') as zipf:
                zipf.extractall(pasta_temp)
        except Exception as e:
            print(f"❌ Erro ao extrair arquivo .mtz: {e}")
            input("Pressione ENTER para tentar novamente...")
            continue

        cores_coletadas = []
        print("🔍 Coletando cores de arquivos XML (pode levar um tempo)...")
        processar_arquivos_para_coleta(pasta_temp, cores_coletadas)

        if not cores_coletadas:
            print("⚠️ Nenhuma cor encontrada nos arquivos XML.")
            input("Pressione ENTER para tentar novamente...")
            shutil.rmtree(pasta_temp)
            continue

        cores_mais_frequentes = mostrar_cores_mais_frequentes(cores_coletadas)

        escolha = input("\nDigite o número da cor para substituir ou digite a cor manualmente (ou 'sair' para encerrar): ").strip()
        if escolha.lower() == 'sair':
            print("👋 Encerrando...")
            shutil.rmtree(pasta_temp)
            break

        if escolha.isdigit():
            idx = int(escolha)
            if 1 <= idx <= len(cores_mais_frequentes):
                cor_antiga = cores_mais_frequentes[idx-1]
            else:
                print("❌ Número inválido.")
                shutil.rmtree(pasta_temp)
                continue
        else:
            cor_antiga = escolha.lower()

        cor_nova = input(f"Digite a nova cor para substituir '{cor_antiga}': ").strip().lower()

        print(f"\n🔄 Substituindo cor '{cor_antiga}' pela '{cor_nova}' nos arquivos XML...")

        # Modificar arquivos .xml e zips internos no temp
        processar_arquivos_recursivamente(pasta_temp, cor_antiga, cor_nova)

        # Recompactar pasta temp para novo .mtz
        novo_nome = nome_mtz.replace('.mtz', '_modificado.mtz')
        print(f"📦 Recompactando arquivos para {novo_nome} ...")
        zipar_diretorio(pasta_temp, novo_nome)

        print(f"\n✅ Processo finalizado. Arquivo salvo como {novo_nome}")

        shutil.rmtree(pasta_temp)

        if input("Deseja fazer outra substituição? (s/n): ").strip().lower() != 's':
            print("👋 Encerrando...")
            break

if __name__ == "__main__":
    main_loop()
