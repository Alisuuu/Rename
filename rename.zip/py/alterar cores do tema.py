import os
import re
import zipfile
import shutil
from collections import Counter

def hex_to_rgb(hex_color):
    """Converte cor hex para RGB"""
    hex_color = hex_color.lstrip('#')
    if len(hex_color) == 3:
        hex_color = ''.join([c*2 for c in hex_color])
    elif len(hex_color) not in [6, 8]:
        return None
    
    try:
        r = int(hex_color[0:2], 16)
        g = int(hex_color[2:4], 16)
        b = int(hex_color[4:6], 16)
        return (r, g, b)
    except:
        return None

def rgb_string_to_tuple(rgb_string):
    """Converte string rgb() para tupla RGB"""
    match = re.search(r'rgb\(\s*(\d{1,3})%?\s*,\s*(\d{1,3})%?\s*,\s*(\d{1,3})%?\s*\)', rgb_string)
    if match:
        return (int(match.group(1)), int(match.group(2)), int(match.group(3)))
    return None

def color_name_to_rgb(color_name):
    """Converte nome da cor para RGB"""
    colors = {
        'red': (255, 0, 0),
        'green': (0, 128, 0),
        'blue': (0, 0, 255),
        'yellow': (255, 255, 0),
        'purple': (128, 0, 128),
        'orange': (255, 165, 0),
        'gray': (128, 128, 128),
        'grey': (128, 128, 128),
        'black': (0, 0, 0),
        'white': (255, 255, 255),
        'cyan': (0, 255, 255),
        'magenta': (255, 0, 255),
        'pink': (255, 192, 203),
        'brown': (165, 42, 42)
    }
    return colors.get(color_name.lower())

def get_color_rgb(color_string):
    """Obtém RGB de qualquer formato de cor"""
    color_string = color_string.strip().lower()
    
    # Hex color
    if color_string.startswith('#'):
        return hex_to_rgb(color_string)
    
    # RGB color
    if color_string.startswith('rgb('):
        return rgb_string_to_tuple(color_string)
    
    # RGBA color (ignora alpha)
    if color_string.startswith('rgba('):
        match = re.search(r'rgba\(\s*(\d{1,3})%?\s*,\s*(\d{1,3})%?\s*,\s*(\d{1,3})%?\s*,\s*[\d.]+\s*\)', color_string)
        if match:
            return (int(match.group(1)), int(match.group(2)), int(match.group(3)))
    
    # Color name
    return color_name_to_rgb(color_string)

def colorize_text(text, rgb_color, bg_color=None):
    """Colore o texto usando códigos ANSI"""
    if not rgb_color:
        return text
    
    r, g, b = rgb_color
    
    # Códigos ANSI para cor do texto
    color_code = f"\033[38;2;{r};{g};{b}m"
    
    # Cor de fundo opcional (para melhor visibilidade)
    bg_code = ""
    if bg_color:
        br, bg, bb = bg_color
        bg_code = f"\033[48;2;{br};{bg};{bb}m"
    
    # Código para resetar a cor
    reset_code = "\033[0m"
    
    return f"{bg_code}{color_code}{text}{reset_code}"

def get_contrasting_bg(rgb_color):
    """Retorna cor de fundo contrastante para melhor legibilidade"""
    if not rgb_color:
        return None
    
    r, g, b = rgb_color
    # Calcula luminância
    luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255
    
    # Se a cor é clara, usa fundo escuro; se escura, usa fundo claro
    if luminance > 0.5:
        return (0, 0, 0)  # Fundo preto
    else:
        return (255, 255, 255)  # Fundo branco

def eh_zip(caminho):
    try:
        with open(caminho, 'rb') as f:
            assinatura = f.read(4)
        return assinatura == b'PK\x03\x04'
    except:
        return False

def coletar_cores_em_conteudo(conteudo):
    padroes_cores = [
        r'#([0-9a-fA-F]{3,8})\b',
        r'rgb\(\s*\d{1,3}%?\s*,\s*\d{1,3}%?\s*,\s*\d{1,3}%?\s*\)',
        r'rgba\(\s*\d{1,3}%?\s*,\s*\d{1,3}%?\s*,\s*\d{1,3}%?\s*,\s*[\d.]+\s*\)',
        r'\b(red|green|blue|yellow|purple|orange|gray|black|white|cyan|magenta|pink|brown)\b'
    ]
    padrao_cor = re.compile('|'.join(padroes_cores), re.IGNORECASE)
    return [m.group(0).lower() for m in padrao_cor.finditer(conteudo)]

def processar_arquivos_para_coleta(diretorio, cores):
    for root, dirs, files in os.walk(diretorio):
        for nome in files:
            caminho = os.path.join(root, nome)
            if nome.lower().endswith('.xml'):
                try:
                    with open(caminho, 'r', encoding='utf-8') as f:
                        conteudo = f.read()
                    cores.extend(coletar_cores_em_conteudo(conteudo))
                except:
                    pass
            else:
                if eh_zip(caminho):
                    pasta_temp_zip = caminho + '_temp'
                    if os.path.exists(pasta_temp_zip):
                        shutil.rmtree(pasta_temp_zip)
                    os.makedirs(pasta_temp_zip)
                    if extrair_zip_sem_ext(caminho, pasta_temp_zip):
                        processar_arquivos_para_coleta(pasta_temp_zip, cores)
                    shutil.rmtree(pasta_temp_zip)

def extrair_zip_sem_ext(caminho_zip_sem_ext, pasta_destino):
    try:
        with zipfile.ZipFile(caminho_zip_sem_ext, 'r') as zipf:
            zipf.extractall(pasta_destino)
        return True
    except Exception as e:
        print(f"❌ Erro ao extrair {caminho_zip_sem_ext}: {e}")
        return False

def atualizar_cache_cores(pasta_temp):
    """Atualiza o cache de cores após uma substituição"""
    cores_coletadas = []
    processar_arquivos_para_coleta(pasta_temp, cores_coletadas)
    return cores_coletadas

def mostrar_cores_mais_frequentes(cores, limite=20):
    contagem = Counter(cores)
    mais_comuns = contagem.most_common(limite)
    
    print("\n" + "="*50)
    print("🎨 CORES MAIS FREQUENTES ENCONTRADAS:")
    print("="*50)
    
    for i, (cor, qtd) in enumerate(mais_comuns, 1):
        rgb = get_color_rgb(cor)
        bg = get_contrasting_bg(rgb)
        
        # Cria o texto colorido
        cor_colorida = colorize_text(f" {cor} ", rgb, bg)
        
        print(f"{i:2d}. {cor_colorida} ({qtd} vezes)")
    
    print("="*50)
    return [cor for cor, _ in mais_comuns]

def alterar_cores_em_xmls(diretorio, cor_antiga, cor_nova):
    cor_antiga_normalizada = cor_antiga.strip().lower()
    
    padroes_cores = [
        r'#([0-9a-fA-F]{3,8})\b',
        r'rgb\(\s*\d{1,3}%?\s*,\s*\d{1,3}%?\s*,\s*\d{1,3}%?\s*\)',
        r'rgba\(\s*\d{1,3}%?\s*,\s*\d{1,3}%?\s*,\s*\d{1,3}%?\s*,\s*[\d.]+\s*\)',
        r'\b(red|green|blue|yellow|purple|orange|gray|black|white|cyan|magenta|pink|brown)\b'
    ]
    padrao_cor = re.compile('|'.join(padroes_cores), re.IGNORECASE)
    
    total_alteracoes = 0
    arquivos_alterados = 0
    
    for root, dirs, files in os.walk(diretorio):
        for nome in files:
            if nome.lower().endswith('.xml'):
                caminho = os.path.join(root, nome)
                alteracoes = 0
                try:
                    with open(caminho, 'r', encoding='utf-8') as f:
                        conteudo = f.read()
                    def substituir_cor(match):
                        nonlocal alteracoes
                        cor_encontrada = match.group(0)
                        if cor_encontrada.lower() == cor_antiga_normalizada:
                            alteracoes += 1
                            return cor_nova
                        return cor_encontrada
                    novo_conteudo = padrao_cor.sub(substituir_cor, conteudo)
                    if alteracoes > 0:
                        with open(caminho, 'w', encoding='utf-8') as f:
                            f.write(novo_conteudo)
                        print(f"✅ {os.path.relpath(caminho, diretorio)}: {alteracoes} alteração(ões)")
                        total_alteracoes += alteracoes
                        arquivos_alterados += 1
                except Exception as e:
                    print(f"❌ Erro ao processar {caminho}: {e}")
    
    return total_alteracoes, arquivos_alterados

def extrair_modificar_recompactar_zip_sem_ext(caminho_zip_sem_ext, cor_antiga, cor_nova):
    pasta_temp = caminho_zip_sem_ext + '_temp'
    if os.path.exists(pasta_temp):
        shutil.rmtree(pasta_temp)
    os.makedirs(pasta_temp)

    try:
        with zipfile.ZipFile(caminho_zip_sem_ext, 'r') as zipf:
            zipf.extractall(pasta_temp)
    except Exception as e:
        print(f"❌ Erro ao extrair arquivo zip interno {caminho_zip_sem_ext}: {e}")
        return 0, 0

    total_alt, arq_alt = alterar_cores_em_xmls(pasta_temp, cor_antiga, cor_nova)

    try:
        with zipfile.ZipFile(caminho_zip_sem_ext, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(pasta_temp):
                for file in files:
                    caminho_completo = os.path.join(root, file)
                    relpath = os.path.relpath(caminho_completo, pasta_temp)
                    zipf.write(caminho_completo, arcname=relpath)
    except Exception as e:
        print(f"❌ Erro ao recompactar arquivo zip interno {caminho_zip_sem_ext}: {e}")

    shutil.rmtree(pasta_temp)
    return total_alt, arq_alt

def processar_arquivos_recursivamente(diretorio, cor_antiga, cor_nova):
    total_alteracoes = 0
    arquivos_alterados = 0
    
    for root, dirs, files in os.walk(diretorio):
        for nome in files:
            caminho = os.path.join(root, nome)
            if nome.lower().endswith('.xml'):
                alt, arq = alterar_cores_em_xmls(root, cor_antiga, cor_nova)
                total_alteracoes += alt
                arquivos_alterados += arq
            else:
                if eh_zip(caminho):
                    print(f"🔄 Processando zip interno: {os.path.relpath(caminho, diretorio)}")
                    alt, arq = extrair_modificar_recompactar_zip_sem_ext(caminho, cor_antiga, cor_nova)
                    total_alteracoes += alt
                    arquivos_alterados += arq
    
    return total_alteracoes, arquivos_alterados

def zipar_diretorio(pasta_origem, caminho_zip):
    with zipfile.ZipFile(caminho_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(pasta_origem):
            for file in files:
                caminho_completo = os.path.join(root, file)
                relpath = os.path.relpath(caminho_completo, pasta_origem)
                zipf.write(caminho_completo, arcname=relpath)

def mostrar_preview_substituicao(cor_antiga, cor_nova):
    """Mostra preview da substituição com cores"""
    print(f"\n🔄 Preview da substituição:")
    
    rgb_antiga = get_color_rgb(cor_antiga)
    bg_antiga = get_contrasting_bg(rgb_antiga)
    cor_antiga_colorida = colorize_text(f" {cor_antiga} ", rgb_antiga, bg_antiga)
    
    rgb_nova = get_color_rgb(cor_nova)
    bg_nova = get_contrasting_bg(rgb_nova)
    cor_nova_colorida = colorize_text(f" {cor_nova} ", rgb_nova, bg_nova)
    
    print(f"   De: {cor_antiga_colorida}")
    print(f"   Para: {cor_nova_colorida}")

def main_loop():
    print("\n🎨 SUBSTITUIDOR DE CORES EM XML DENTRO DE .MTZ")
    print("=" * 60)
    print("📝 O script mantém a sessão ativa para múltiplas substituições")
    print("💾 Só empacota o arquivo final quando você decidir sair")
    print("=" * 60)

    # Procura arquivo .mtz
    mtz_arquivos = [f for f in os.listdir('.') if f.lower().endswith('.mtz')]
    if not mtz_arquivos:
        print("❌ Nenhum arquivo .mtz encontrado no diretório atual.")
        return

    nome_mtz = mtz_arquivos[0]
    pasta_temp = './temp_root'
    
    # Remove pasta temporária se existir
    if os.path.exists(pasta_temp):
        shutil.rmtree(pasta_temp)
    os.makedirs(pasta_temp)

    # Extrai o arquivo .mtz
    print(f"📦 Extraindo arquivo .mtz: {nome_mtz} ...")
    try:
        with zipfile.ZipFile(nome_mtz, 'r') as zipf:
            zipf.extractall(pasta_temp)
    except Exception as e:
        print(f"❌ Erro ao extrair arquivo .mtz: {e}")
        return

    # Coleta inicial de cores
    print("🔍 Coletando cores iniciais dos arquivos XML...")
    cores_coletadas = []
    processar_arquivos_para_coleta(pasta_temp, cores_coletadas)

    if not cores_coletadas:
        print("⚠️ Nenhuma cor encontrada nos arquivos XML.")
        shutil.rmtree(pasta_temp)
        return

    # Loop principal de substituições
    substituicoes_realizadas = 0
    
    while True:
        cores_mais_frequentes = mostrar_cores_mais_frequentes(cores_coletadas)
        
        print(f"\n📊 Total de substituições realizadas: {substituicoes_realizadas}")
        print("\n🎯 OPÇÕES:")
        print("   • Digite o número da cor para substituir")
        print("   • Digite a cor manualmente (ex: #ff0000, red, rgb(255,0,0))")
        print("   • Digite 'sair' para finalizar e empacotar")
        
        escolha = input("\n🎨 Sua escolha: ").strip()
        
        if escolha.lower() == 'sair':
            break

        # Processa a escolha da cor antiga
        if escolha.isdigit():
            idx = int(escolha)
            if 1 <= idx <= len(cores_mais_frequentes):
                cor_antiga = cores_mais_frequentes[idx-1]
            else:
                print("❌ Número inválido.")
                continue
        else:
            cor_antiga = escolha.lower()

        # Solicita a nova cor
        cor_nova = input(f"🎨 Digite a nova cor para substituir '{cor_antiga}': ").strip().lower()
        
        # Mostra preview da substituição
        mostrar_preview_substituicao(cor_antiga, cor_nova)
        
        confirmacao = input("✅ Confirma a substituição? (s/n): ").strip().lower()
        if confirmacao != 's':
            print("❌ Substituição cancelada.")
            continue

        print(f"\n🔄 Substituindo '{cor_antiga}' por '{cor_nova}'...")

        # Realiza a substituição
        total_alt, arq_alt = processar_arquivos_recursivamente(pasta_temp, cor_antiga, cor_nova)
        
        if total_alt > 0:
            print(f"\n✅ Substituição concluída!")
            print(f"   📝 {total_alt} alterações em {arq_alt} arquivo(s)")
            substituicoes_realizadas += 1
            
            # Atualiza o cache de cores
            print("🔄 Atualizando lista de cores...")
            cores_coletadas = atualizar_cache_cores(pasta_temp)
            print("✅ Cache de cores atualizado!")
        else:
            print(f"⚠️ Nenhuma ocorrência da cor '{cor_antiga}' foi encontrada.")

        print("\n" + "-"*50)

    # Empacotamento final
    if substituicoes_realizadas > 0:
        novo_nome = nome_mtz.replace('.mtz', '_modificado.mtz')
        print(f"\n📦 Empacotando arquivo final: {novo_nome} ...")
        zipar_diretorio(pasta_temp, novo_nome)
        print(f"✅ Processo finalizado!")
        print(f"📁 Arquivo salvo como: {novo_nome}")
        print(f"🎯 Total de substituições: {substituicoes_realizadas}")
    else:
        print("ℹ️ Nenhuma substituição foi realizada.")

    # Limpeza
    shutil.rmtree(pasta_temp)
    print("🧹 Arquivos temporários removidos.")
    print("👋 Encerrando...")

if __name__ == "__main__":
    main_loop()