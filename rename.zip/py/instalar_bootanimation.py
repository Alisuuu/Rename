import os
import zipfile
import shutil
import tempfile

def process_mtz_file():
    # 1. Subir para a pasta superior
    os.chdir('..')
    current_dir = os.getcwd()
    print(f"Diretório atual: {current_dir}")
    
    # 2. Procurar arquivo MTZ
    mtz_files = [f for f in os.listdir() if f.lower().endswith('.mtz')]
    if not mtz_files:
        print("Nenhum arquivo MTZ encontrado.")
        return
    
    mtz_file = mtz_files[0]
    mtz_path = os.path.join(current_dir, mtz_file)
    print(f"Arquivo MTZ encontrado: {mtz_path}")
    
    # 3. Procurar pasta boot com arquivo ZIP
    boot_dir = os.path.join(current_dir, 'boot')
    if not os.path.exists(boot_dir):
        print("Pasta 'boot' não encontrada no diretório.")
        return
    
    zip_files = [f for f in os.listdir(boot_dir) if f.lower().endswith('.zip')]
    if not zip_files:
        print("Nenhum arquivo ZIP encontrado na pasta boot.")
        return
    
    zip_path = os.path.join(boot_dir, zip_files[0])
    print(f"Arquivo ZIP encontrado: {zip_path}")
    
    # 4. Criar diretório temporário
    temp_dir = tempfile.mkdtemp(prefix='mtz_')
    print(f"Diretório temporário: {temp_dir}")
    
    try:
        # 5. Extrair MTZ original
        with zipfile.ZipFile(mtz_path, 'r') as zip_ref:
            zip_ref.extractall(temp_dir)
        print("MTZ extraído com sucesso.")
        
        # 6. Criar pasta boots se não existir
        boots_dir = os.path.join(temp_dir, 'boots')
        os.makedirs(boots_dir, exist_ok=True)
        print(f"Pasta 'boots' pronta: {boots_dir}")
        
        # 7. Procurar arquivos no ZIP (common/cool_modules/)
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            target_files = [
                f for f in zip_ref.namelist() 
                if 'common/cool_modules/' in f.lower() and 
                f.lower().endswith(('.zip', '.mp3'))
            ]
            
            if not target_files:
                print("Nenhum arquivo encontrado em common/cool_modules/")
                return
            
            # Copiar arquivos encontrados para boots/
            for file in target_files:
                filename = os.path.basename(file)
                dest_path = os.path.join(boots_dir, filename)
                
                with zip_ref.open(file) as source, open(dest_path, 'wb') as target:
                    shutil.copyfileobj(source, target)
                print(f"Arquivo copiado: {filename}")
        
        # 8. Criar novo MTZ (substituindo o original)
        temp_mtz = mtz_path + '.temp'
        with zipfile.ZipFile(temp_mtz, 'w', zipfile.ZIP_DEFLATED) as new_zip:
            for root, dirs, files in os.walk(temp_dir):
                for file in files:
                    path = os.path.join(root, file)
                    arcname = os.path.relpath(path, temp_dir)
                    new_zip.write(path, arcname)
        
        # Substituir o original
        shutil.move(temp_mtz, mtz_path)
        print(f"MTZ atualizado com sucesso: {mtz_path}")
        
    except Exception as e:
        print(f"Erro: {str(e)}")
    finally:
        # Limpeza
        shutil.rmtree(temp_dir, ignore_errors=True)
        if 'temp_mtz' in locals() and os.path.exists(temp_mtz):
            os.remove(temp_mtz)
        print("Processo concluído.")

if __name__ == "__main__":
    process_mtz_file()