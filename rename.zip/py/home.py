import sys
import subprocess
import os

# --- Configuração da Primeira Opção Fixa ---
# O nome que aparece no menu
PRIMEIRA_OPCAO_TEXTO = "extrair os ícones do apk para mtz"
# O nome do arquivo .py na pasta superior (um nível acima da pasta onde home.py está)
PRIMEIRA_OPCAO_ARQUIVO = "app.py" # Assumindo que o script na pasta superior se chama app.py


# --- Função para Executar um Script Externo ---
def executar_script(caminho_completo_do_script):
    """Função auxiliar para executar um script Python externo."""
    print("\n" + "="*40)
    # os.path.basename() pega apenas o nome do arquivo do caminho completo
    print(f"  >>> Executando: {os.path.basename(caminho_completo_do_script)} <<<")
    print("="*40)
    try:
        # Verifica se o arquivo existe antes de tentar executar
        if not os.path.exists(caminho_completo_do_script):
             print(f"\n!!! ERRO: O arquivo '{os.path.basename(caminho_completo_do_script)}' não foi encontrado no caminho '{caminho_completo_do_script}'. !!!")
             # Tenta dar uma dica para o script fixo, se for ele que faltou
             if os.path.basename(caminho_completo_do_script) == PRIMEIRA_OPCAO_ARQUIVO:
                 print(f"    => Verifique se o arquivo '{PRIMEIRA_OPCAO_ARQUIVO}' existe na pasta superior.")
             return

        # Chama o interpretador python para executar o script selecionado
        # sys.executable garante que é o mesmo interpretador Python que está rodando este script
        # check=True fará levantar um erro (CalledProcessError) se o script chamado retornar um código de erro
        # O output (prints, etc.) do script chamado aparecerá direto no terminal.
        process = subprocess.run([sys.executable, caminho_completo_do_script], check=True)

        print(f"\n>>> Execução de {os.path.basename(caminho_completo_do_script)} concluída (Código de Saída: {process.returncode}).")

    except FileNotFoundError:
         # Este erro pode ocorrer se sys.executable não for encontrado (muito raro)
         print("\n!!! ERRO: O interpretador Python ('python') não foi encontrado no sistema. Verifique a instalação do Python. !!!")
    except subprocess.CalledProcessError as e:
        print(f"\n!!! ERRO durante a execução de {os.path.basename(caminho_completo_do_script)}: O script retornou um erro. !!!")
        print(f"    Código de Saída: {e.returncode}")
        # Se quiser ver o stderr do script chamado, pode tentar descomentar (pode dar erro se stderr for None)
        # if e.stderr is not None: print(f"    Saída de Erro (stderr):\n{e.stderr.decode()}")
    except Exception as e:
         # Captura qualquer outro erro inesperado durante a execução
         print(f"\n!!! Ocorreu um erro inesperado ao tentar executar {os.path.basename(caminho_completo_do_script)}: {e} !!!")


# --- Função para Exibir o Menu Estático (Título/Cabeçalho) ---
def exibir_cabecalho_menu():
    """Exibe o título e o cabeçalho fixo do menu no terminal."""
    print("\n" + "#" * 40)
    print("#" + " " * 38 + "#")
    print(f"#{" MENU PRINCIPAL ":^38}#") # Título centralizado
    print(f"#{" rename ":^38}#")         # Cabeçalho "rename" centralizado
    print("#" + " " * 38 + "#")
    print("#" * 40)


# --- Loop Principal do Programa (O Launcher) ---
def main():
    """
    Controla a exibição do menu com opção fixa + opções dinâmicas,
    e executa o script selecionado pelo usuário.
    """

    # Pega o caminho completo do diretório onde este script (home.py) está localizado
    script_dir = os.path.dirname(os.path.abspath(__file__))
    # Pega o caminho do diretório pai (um nível acima)
    parent_dir = os.path.dirname(script_dir)

    # Define o caminho completo para o script da primeira opção (na pasta superior)
    caminho_primeira_opcao_script = os.path.join(parent_dir, PRIMEIRA_OPCAO_ARQUIVO)
    # print(f"DEBUG: Caminho 1ª opção: {caminho_primeira_opcao_script}") # Debug opcional

    while True: # Loop infinito para manter o menu rodando até que o usuário escolha sair

        # 1. Encontrar arquivos .py na pasta do script (exceto home.py) para as opções dinâmicas
        todos_itens_na_pasta = os.listdir(script_dir)
        # Filtra a lista para pegar apenas arquivos .py na pasta atual, excluindo o próprio home.py
        arquivos_dinamicos = [
            f for f in todos_itens_na_pasta
            if os.path.isfile(os.path.join(script_dir, f))
            and f.endswith('.py')
            and f != os.path.basename(__file__) # Exclui o próprio home.py
        ]
        arquivos_dinamicos.sort() # Ordena os nomes dos arquivos por ordem alfabética para uma lista consistente

        # 2. Construir a lista completa de scripts que podem ser lançados (mapa número -> caminho)
        # Começamos com a opção fixa
        opcoes_scripts_map = {
            1: caminho_primeira_opcao_script
        }
        # Adiciona os arquivos dinâmicos encontradas, começando a numeração após a opção fixa
        numero_opcao_dinamica = 2
        for file_name in arquivos_dinamicos:
            caminho_completo = os.path.join(script_dir, file_name)
            opcoes_scripts_map[numero_opcao_dinamica] = caminho_completo
            numero_opcao_dinamica += 1 # Incrementa o número para a próxima opção dinâmica

        # 3. Exibir o menu (cabeçalho + opções)
        exibir_cabecalho_menu() # Exibe o título e cabeçalho fixo

        print("Opções disponíveis:")
        # Exibe a primeira opção fixa
        print(f"  1 - {PRIMEIRA_OPCAO_TEXTO}")

        # Exibe as opções dinâmicas encontradas
        if not arquivos_dinamicos:
             # Se não encontrou arquivos dinâmicos, avisa
            print("  (Nenhum outro arquivo .py encontrado nesta pasta)")
            # print("-" * 40) # Opcional: separador

        else:
            # Itera sobre o mapa a partir da segunda opção (key=2)
            for num_opcao in sorted(opcoes_scripts_map.keys()): # Ordena as chaves (números das opções)
                if num_opcao == 1: continue # Já exibimos a opção 1

                caminho_script = opcoes_scripts_map[num_opcao]
                nome_arquivo = os.path.basename(caminho_script)
                # Exibe o nome do arquivo SEM a extensão .py
                nome_amigavel = nome_arquivo[:-3] if nome_arquivo.endswith('.py') else nome_arquivo # Remove .py se existir

                print(f"  {num_opcao} - {nome_amigavel}")

        # Exibe a opção de sair (sempre 0)
        print("-" * 40)
        print("  0 - Sair")
        print("-" * 40)

        # 4. Obter e processar a escolha do usuário
        escolha = input("Digite o número da sua escolha: ").strip()

        if escolha == '0':
            print("\nSaindo do programa. Até mais!")
            sys.exit()
        else:
            try:
                # Tenta converter a escolha para um número inteiro
                num_escolhido = int(escolha)

                # Verifica se o número escolhido é uma das opções válidas (está no nosso mapa)
                if num_escolhido in opcoes_scripts_map:
                    # Pega o caminho completo do script selecionado usando o número escolhido como chave
                    caminho_script_selecionado = opcoes_scripts_map[num_escolhido]
                    # Executa o script selecionado usando a função auxiliar
                    executar_script(caminho_script_selecionado)
                else:
                    # Se o número estiver fora das chaves válidas no mapa
                    print("\n!!! Número da opção fora do intervalo válido. !!!")

            except ValueError:
                # Captura o erro se o usuário digitar algo que não pode ser convertido para número
                print("\n!!! Entrada inválida. Por favor, digite um número correspondente a uma opção. !!!")
            except Exception as e:
                 # Captura qualquer outro erro inesperado durante o processamento da escolha
                 print(f"\n!!! Ocorreu um erro inesperado ao processar a escolha: {e} !!!")

        # 5. Pausar antes de mostrar o menu novamente
        print("\nPressione Enter para continuar...")
        input()


# --- Início da Execução do Script ---
if __name__ == "__main__":
    main()