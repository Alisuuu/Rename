import os
import zipfile
import time
import glob
import shutil
import tempfile

def compress_or_add_to_mtz():
    icons_file = 'icons'
    description_file = 'description.xml'

    new_mtz_name = 'customicons.mtz'

    print("\n🚀 app1.py: Iniciando...")
    time.sleep(1)

    if not os.path.exists(icons_file):
        print(f"❌ ERRO em app1.py: O arquivo '{icons_file}' não foi encontrado no mesmo diretório. Ele é essencial para ambas as operações.")
        return

    mtz_files = glob.glob('*.mtz')

    if mtz_files:
        target_mtz_path = mtz_files[0]
        print(f"🔍 app1.py: Arquivo .mtz encontrado: '{target_mtz_path}'.")

        try:
            with tempfile.TemporaryDirectory() as temp_dir:
                print(f"📂 app1.py: Diretório temporário criado: '{temp_dir}'")

                print(f"📦 app1.py: Extraindo conteúdo de '{target_mtz_path}' para '{temp_dir}'...")
                with zipfile.ZipFile(target_mtz_path, 'r') as zip_ref:
                    zip_ref.extractall(temp_dir)
                print("✅ app1.py: Conteúdo extraído com sucesso.")

                icons_in_temp_path = os.path.join(temp_dir, icons_file)

                if os.path.exists(icons_in_temp_path):
                    print(f"🗑️ app1.py: Excluindo '{icons_file}' existente no diretório temporário...")
                    try:
                        os.remove(icons_in_temp_path)
                        print(f"✅ app1.py: Arquivo '{icons_file}' excluído do temporário.")
                    except OSError as e:
                        print(f"❌ AVISO em app1.py: Não foi possível excluir o arquivo '{icons_file}' do temporário: {e}. Continuando...")

                print(f"📋 app1.py: Copiando o novo '{icons_file}' para o diretório temporário...")
                try:
                    shutil.copy2(icons_file, temp_dir)
                    print(f"✅ app1.py: Novo '{icons_file}' copiado para o temporário.")
                except FileNotFoundError:
                     print(f"❌ ERRO em app1.py: O arquivo original '{icons_file}' sumiu! Não foi possível copiar.")
                     return
                except Exception as e:
                     print(f"❌ ERRO em app1.py: Falha ao copiar o novo '{icons_file}' para o temporário: {e}.")
                     return

                new_zip_temp_path = target_mtz_path + '.newtemp'
                print(f"🔄 app1.py: Recompactando o conteúdo do temporário para '{new_zip_temp_path}'...")

                try:
                    with zipfile.ZipFile(new_zip_temp_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                        for root, _, files in os.walk(temp_dir):
                            for file in files:
                                file_path = os.path.join(root, file)
                                arcname = os.path.relpath(file_path, temp_dir)
                                zipf.write(file_path, arcname)
                    print("✅ app1.py: Conteúdo recompactado com sucesso.")

                except Exception as e:
                    print(f"❌ ERRO em app1.py: Falha durante a recompactação para '{new_zip_temp_path}': {e}.")
                    if os.path.exists(new_zip_temp_path):
                        try: os.remove(new_zip_temp_path)
                        except: pass
                    return

                print(f"덮개 app1.py: Substituindo o arquivo original '{target_mtz_path}'...")
                try:
                    os.remove(target_mtz_path)
                    shutil.move(new_zip_temp_path, target_mtz_path)
                    print(f"✅ app1.py: '{target_mtz_path}' atualizado com sucesso.")
                    print("🎉 app1.py: Processo concluído (arquivo .mtz existente atualizado com o novo icons)!")

                    print(f"🗑️ app1.py: Excluindo arquivo original 'icons' gerado pelo script principal...")
                    try:
                        os.remove(icons_file)
                        print(f"✅ app1.py: Arquivo '{icons_file}' excluído com sucesso.")
                    except OSError as e:
                        print(f"❌ ERRO em app1.py: Não foi possível excluir o arquivo original '{icons_file}': {e}")


                except Exception as e:
                    print(f"❌ ERRO em app1.py: Falha ao substituir '{target_mtz_path}': {e}.")
                    print(f"  - O arquivo temporário recompactado '{new_zip_temp_path}' foi mantido para depuração.")
                    return

        except Exception as e:
             print(f"❌ ERRO inesperado em app1.py durante o processo de extração/modificação/recompactação: {e}")

        return

    else:
        print("🤷 app1.py: Nenhum arquivo .mtz encontrado no diretório.")
        print("🔄 app1.py: Prosseguindo com a criação de um novo arquivo .mtz...")

        if not os.path.exists(description_file):
            print(f"❌ ERRO em app1.py: O arquivo '{description_file}' não foi encontrado. Ele é necessário para criar um novo arquivo .mtz.")
            return

        temp_output_zip_name = 'temp_customicons.zip'

        try:
            print(f"📦 app1.py: Criando arquivo zip temporário '{temp_output_zip_name}' com '{icons_file}' e '{description_file}'...")
            with zipfile.ZipFile(temp_output_zip_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
                zipf.write(icons_file, arcname=icons_file)

                zipf.write(description_file, arcname=description_file)

            print(f"✅ app1.py: Arquivo zip temporário criado: '{temp_output_zip_name}'")

            os.rename(temp_output_zip_name, new_mtz_name)

            print(f"✅ app1.py: Arquivo renomeado para '{new_mtz_name}'.")
            print("🎉 app1.py: Processo concluído (novo arquivo .mtz criado)!")

            print(f"🗑️ app1.py: Excluindo arquivo original 'icons' gerado pelo script principal...")
            try:
                os.remove(icons_file)
                print(f"✅ app1.py: Arquivo '{icons_file}' excluído com sucesso.")
            except OSError as e:
                print(f"❌ ERRO em app1.py: Não foi possível excluir o arquivo original '{icons_file}': {e}")

        except FileNotFoundError:
            print(f"❌ ERRO em app1.py: Um dos arquivos ({icons_file} ou {description_file}) não foi encontrado durante a compactação.")
        except Exception as e:
            print(f"❌ ERRO inesperado em app1.py durante a compactação ou renomeação do novo MTZ: {e}")


if __name__ == "__main__":
    compress_or_add_to_mtz()