import os
import re
import zipfile
import xml.etree.ElementTree as ET
from shutil import copy2
import time
import subprocess
import sys

def sanitize_filename(name):
    return re.sub(r'[\\/*?:"<>|]', "", name).strip()

def extract_package(component):
    patterns = [
        r'\{([a-zA-Z0-9._]+)(?:/[^}]*)?\}',
        r'([a-zA-Z0-9._]+)(?:/\.[a-zA-Z0-9_]+)?',
        r'([a-zA-Z0-9._]+)'
    ]
    for pattern in patterns:
        match = re.search(pattern, component or "")
        if match:
            return match.group(1)
    return None

def extract_appfilter_from_apk(apk_path):
    locations = [
        'assets/appfilter.xml',
        'res/xml/appfilter.xml',
        'assets/appfilter_*.xml',
        'res/xml/appfilter_*.xml'
    ]

    with zipfile.ZipFile(apk_path, 'r') as apk:
        for location in locations:
            if '*' in location:
                for file in apk.namelist():
                    if re.match(location.replace('*', '.*'), file):
                        try:
                            with apk.open(file) as f:
                                content = f.read().decode('utf-8', errors='ignore')
                                content = content.replace('\x00', '')
                                return ET.fromstring(content)
                        except:
                            continue
            else:
                if location in apk.namelist():
                    try:
                        with apk.open(location) as f:
                            content = f.read().decode('utf-8', errors='ignore')
                            content = content.replace('\x00', '')
                            return ET.fromstring(content)
                    except:
                        continue

        for file in apk.namelist():
            if 'appfilter' in file.lower() and file.endswith('.xml'):
                try:
                    with apk.open(file) as f:
                        content = f.read().decode('utf-8', errors='ignore')
                        content = content.replace('\x00', '')
                        return ET.fromstring(content)
                except:
                    continue
    return None


def extract_icons_from_apk(apk_path):
    icons = {}
    icon_dirs = [
        'res/drawable-nodpi-v4',
        'res/drawable-xxhdpi-v4',
        'res/drawable-xxhdpi',
        'res/drawable',
        'assets/icons'
    ]

    with zipfile.ZipFile(apk_path, 'r') as apk:
        for file in apk.namelist():
            if any(file.startswith(dir) for dir in icon_dirs) and file.lower().endswith(('.png', '.webp', '.jpg')):
                icon_name = os.path.splitext(os.path.basename(file))[0]
                icons[icon_name] = file
    return icons

def main():
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    APK_DIR = os.path.join(BASE_DIR, 'apk')
    OUTPUT_DIR = os.path.join(BASE_DIR, 'icons2', 'res', 'drawable-xxhdpi')
    OUTPUT_ZIP = os.path.join(BASE_DIR, 'icons')

    os.makedirs(APK_DIR, exist_ok=True)
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    print("\n=== Processador de Ícones com APK ===")

    apk_files = [f for f in os.listdir(APK_DIR) if f.endswith('.apk')]
    if not apk_files:
        print("\nERRO: Nenhum APK encontrado na pasta 'apk/'")
        return

    apk_path = os.path.join(APK_DIR, apk_files[0])
    print(f"\nProcessando APK: {apk_files[0]}")

    root = extract_appfilter_from_apk(apk_path)
    if root is None:
        print("\nERRO: Não foi possível encontrar appfilter.xml válido em:")
        print("- assets/appfilter.xml")
        print("- res/xml/appfilter.xml")
        print("- outros locais padrão")
        return

    icons = extract_icons_from_apk(apk_path)
    if not icons:
        print("\nAVISO: Nenhum ícone encontrado nas pastas padrão do APK")
        pass

    items = []
    for tag in ['item', 'icon', 'app', 'application']:
        items.extend(root.findall(f'.//{tag}'))

    if not items:
        print("\nERRO: Nenhuma entrada válida no appfilter.xml")
        return

    print(f"\nEncontradas {len(items)} entradas no appfilter.xml")
    print(f"Encontrados {len(icons)} ícones no APK")

    processed = set()
    success = 0
    errors = 0
    start_time = time.time()

    print("\nIniciando processamento...")
    with zipfile.ZipFile(apk_path, 'r') as apk:
        for i, item in enumerate(items, 1):
            component = (item.get('component') or item.get('name') or
                         item.get('package') or item.get('app'))

            drawable = (item.get('drawable') or item.get('icon') or
                       item.get('image') or item.get('src'))

            if not component or not drawable:
                errors += 1
                continue

            try:
                pkg = extract_package(component)
                if not pkg:
                    errors += 1
                    continue

                sanitized = sanitize_filename(pkg)
                if sanitized in processed:
                    continue

                icon_found = False
                for ext in ['', '.png', '.webp', '.jpg']:
                    icon_name = f"{drawable}{ext}"
                    if icon_name in icons:
                        with apk.open(icons[icon_name]) as icon_file:
                            with open(os.path.join(OUTPUT_DIR, f"{sanitized}.png"), 'wb') as f:
                                f.write(icon_file.read())
                        processed.add(sanitized)
                        success += 1
                        icon_found = True
                        break

                if not icon_found:
                    errors += 1

                if i % 10 == 0 or i == len(items):
                    elapsed = time.time() - start_time
                    print(f"\rProcessados {i}/{len(items)} | Ícones: {success} | Erros: {errors} | {elapsed:.1f}s", end="")

            except Exception as e:
                errors += 1
                continue

    if success == 0:
        print("\n\nAVISO: Nenhum ícone processado. Verifique:")
        print(f"- Correspondência entre {len(items)} entradas XML e {len(icons)} ícones")
        print("- O APK pode usar um padrão de nomes diferente")
        pass

    print("\n\nCriando arquivo compactado...")
    try:
        with zipfile.ZipFile(OUTPUT_ZIP, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root_dir, _, files in os.walk(os.path.join(BASE_DIR, 'icons2')):
                for file in files:
                    file_path = os.path.join(root_dir, file)
                    arcname = os.path.relpath(file_path, os.path.join(BASE_DIR, 'icons2'))
                    zipf.write(file_path, arcname)
        print(f"Arquivo compactado gerado: {OUTPUT_ZIP}")
    except Exception as e:
        print(f"\nERRO ao criar o arquivo compactado: {e}")
        return

    print("Limpando arquivos temporários...")
    for icon in os.listdir(OUTPUT_DIR):
        if icon.endswith('.png'):
            try:
                os.remove(os.path.join(OUTPUT_DIR, icon))
            except Exception as e:
                print(f"AVISO: Não foi possível remover {icon}: {e}")

    total_time = time.time() - start_time
    print("\n✅ Processo principal concluído!")
    print(f"• Ícones processados: {success}")
    print(f"• Erros encontrados: {errors}")
    print(f"• Tempo total: {total_time:.2f}s")
    print(f"• Arquivo gerado: {OUTPUT_ZIP}")
    print(f"• Estrutura: icons2/res/drawable-xxhdpi/")

    run_app1()

    print("\nFim do script principal.")


def run_app1():
    app1_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'app1.py')

    print(f"\n🚀 Iniciando {app1_path}...")

    try:
        subprocess.run([sys.executable, app1_path], check=True)
        print(f"✅ {app1_path} executado com sucesso.")
    except FileNotFoundError:
        print(f"❌ ERRO: O arquivo {app1_path} não foi encontrado. Certifique-se de que o caminho está correto.")
    except subprocess.CalledProcessError as e:
        print(f"❌ ERRO: Ocorreu um erro ao executar {app1_path}.")
        print(f"Código de retorno: {e.returncode}")
    except Exception as e:
        print(f"❌ Ocorreu um erro inesperado ao tentar executar {app1_path}: {e}")


if __name__ == "__main__":
    main()